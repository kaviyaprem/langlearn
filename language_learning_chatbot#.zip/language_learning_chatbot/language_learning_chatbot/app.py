from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
from llama_cpp import Llama
import hashlib

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with your secret key

# MySQL Configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'language_learning_chatbot'
}

# Model path (replace with your actual model path)
model_path = r'C:\Users\LENOVO\Downloads\language_learning_chatbot\language_learning_chatbot\mistral-7b-instruct-v0.2.Q4_K_M.gguf'

# Initialize the LLM with error handling
try:
    llm = Llama(model_path=model_path, n_gpu_layers=-1)
except FileNotFoundError:
    print("Error: Model file not found. Please check the path.")
    exit(1)
except Exception as e:
    print(f"Error initializing LLM: {e}")
    exit(1)

def create_connection():
    connection = None
    try:
        connection = mysql.connector.connect(**db_config)
    except mysql.connector.Error as e:
        print(f"Error: '{e}'")
    return connection

@app.route('/')
def home():
    if 'loggedin' in session:
        return redirect(url_for('chat'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        connection = create_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute('SELECT * FROM user WHERE email = %s AND password_hash = %s', (email, password_hash))
        account = cursor.fetchone()
        cursor.close()
        connection.close()
        if account:
            session['loggedin'] = True
            session['id'] = account['id']
            session['education'] = account['education']
            session['skills'] = account['skills']
            return redirect(url_for('chat'))
        else:
            return render_template('login.html', error='Incorrect email/password!')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        education = request.form['education']
        skills = ','.join(request.form.getlist('skills'))
        password_hash = hashlib.sha256(password.encode()).hexdigest()

        connection = create_connection()
        cursor = connection.cursor()

        # Check if the email already exists
        cursor.execute('SELECT * FROM user WHERE email = %s', (email,))
        existing_user = cursor.fetchone()
        if existing_user:
            cursor.close()
            connection.close()
            return render_template('register.html', error='This email is already registered.')

        try:
            cursor.execute('INSERT INTO user (email, password_hash, education, skills) VALUES (%s, %s, %s, %s)',
                           (email, password_hash, education, skills))
            connection.commit()
        except mysql.connector.Error as err:
            print(f"Error: {err}")
            return render_template('register.html', error='An error occurred during registration. Please try again.')
        finally:
            cursor.close()
            connection.close()
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/chat', methods=['GET', 'POST'])
def chat():
    if 'loggedin' in session:
        if request.method == 'POST':
            user_education = session['education']
            user_skills = session['skills']
            
            # Constructing a personalized prompt with specific instructions based on the user's education level
            prompt = (
                f"As a {user_education}, I want to improve my {user_skills}. Please provide some suggestions, corrections, and feedback. Do not answer anything other than english language learning related queries"
            )
            
            if user_education == "High School":
                prompt += "Make the explanations simple and easy to understand, suitable for a high school student."
            elif user_education == "College":
                prompt += "Provide detailed explanations and examples, suitable for a college student."
            elif user_education == "Researcher":
                prompt += "Give in-depth explanations and advanced tips, suitable for a researcher."

            prompt += " Focus on English language learning and make it interactive."

            try:
                output = llm(prompt=prompt, max_tokens=100)
                predicted_response = output['choices'][0]['text']  # Adjust according to the model's response format
            except Exception as e:
                print(f"Error during prediction: {e}")
                return render_template('chat.html', error="An error occurred during prediction. Please try again later.")
            
            return render_template('chat.html', response=predicted_response)
        return render_template('chat.html')
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('education', None)
    session.pop('skills', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
