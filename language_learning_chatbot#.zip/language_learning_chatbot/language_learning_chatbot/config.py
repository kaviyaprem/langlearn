db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'language_learning_chatbot'
}
